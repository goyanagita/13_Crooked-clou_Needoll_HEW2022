#include "GameObject.h"
#include "Game.h"



GameObject::GameObject(class Game* game)
{
	Game = game;
}

GameObject::~GameObject()
{

}
