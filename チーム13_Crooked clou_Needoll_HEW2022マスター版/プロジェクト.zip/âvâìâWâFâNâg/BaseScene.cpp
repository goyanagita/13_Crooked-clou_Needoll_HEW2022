#include "BaseScene.h"

BaseScene::BaseScene(SceneChanger * changer)
{
	m_SceneChanger = changer;
}
