#include "Character.h"
#include "Game.h"
Character::Character(class Game * game) :GameObject(game)
{

}
